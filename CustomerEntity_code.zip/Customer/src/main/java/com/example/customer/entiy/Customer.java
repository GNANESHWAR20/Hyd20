package com.example.customer.entiy;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long customerid;
	private String customerName;
	private long customerPhone;
	private String customerEmail;
	public Customer() {
		
	}
	public Customer(long customerid, String customerName, long customerPhone, String customerEmail) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerEmail = customerEmail;
	}
	public long getCustomerid() {
		return customerid;
	}
	public void setCustomerid1(long customerid) {
		this.customerid = customerid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(Long string) {
		this.customerPhone = string;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customerName=" + customerName + ", customerPhone="
				+ customerPhone + ", customerEmail=" + customerEmail + "]";
	}
	public void setCustomerid(String customerid2) {
		// TODO Auto-generated method stub
		
	}
	

}
