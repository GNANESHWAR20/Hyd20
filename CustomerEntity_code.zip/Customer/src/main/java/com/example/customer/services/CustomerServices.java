package com.example.customer.services;

import java.util.List;

import com.example.customer.entiy.Customer;

public interface CustomerServices {

	Customer saveCustomer(Customer customer);

	
	static List<Customer> fetchcustomerList() {
		return null;
	}


	static void delCustomerById(Long customerid) {
		// TODO Auto-generated method stub
		
	}

	static Customer updateCustomers(Long customerid, Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}


	Customer updateCustomer(Long customerid, Customer customer);


	void deleteCustomerById(Long customerid);


	Customer fetchCustomerById(Long customerid);


	List<Customer> fetchCustomerList();

}
